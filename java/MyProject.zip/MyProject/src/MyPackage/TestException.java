package MyPackage;

import java.io.FileInputStream;

public class TestException {

	public static void main(String[] args) {
		   // try                           compiletime exception
		   // {
		    	//Class.forName("con.mysql.jdbc.Driver");
		    //}
		    //catch(Exception e)
		    //{
		    	//System.out.println(40);
		    	//e.printStackTrace();
		    	//System.out.println(e);
		    //}
		    try
		    {
			int a=100, b=0, c;                             ///runtime exception
			c=a/b;
			System.out.println(c);
		    }
		    catch(Exception e)
		    {
		    	System.out.println(e);
		    }
		    finally
		    {
		    System.out.println("file closed");
		    }
	}

}
