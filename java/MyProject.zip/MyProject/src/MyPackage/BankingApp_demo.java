package MyPackage;

import java.util.Scanner;

public class BankingApp_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank b =new Bank("sankalp","333");
		b.myMenu();
	}

}
class Bank
{
	int Bal;
	int pretransaction;
	String customerName;
	String customerId;
	
	Bank(String cname,String cid)
	{
		customerName =cname;
		customerId = cid;
	}
	
	void Deposit(int amount)
	{
		if(amount != 0)
		{
		Bal = Bal +amount;
		pretransaction = amount;
		}
	}
	void Withdraw(int amount)
	{
		if(amount != 0)
		{
		Bal = Bal - amount;
		pretransaction = -amount;
		}
	}
	void getPretransaction()
	{
		if(pretransaction > 0)
		{
			System.out.println("Deposit "+pretransaction);
		}
		else if(pretransaction < 0)
		{
			System.out.println("Withdraw " +Math.abs(pretransaction));
		}
		else
		{
			System.out.println("No transaction occured");
		}
	}
	void myMenu()
	{
		char option = '\0';
		Scanner sc =new Scanner (System.in);
		
		System.out.println("welcome "+customerName);
		System.out.println("Your id is"+customerId);
		System.out.println("\n");
		System.out.println("A. cheak balance");
		System.out.println("B. deposit");
		System.out.println("C. withdraw");
		System.out.println("D. previous transaction");		
		System.out.println("E. Exit");
		
		do
		{
			System.out.println("***********************************************");
			System.out.println("Enter the option");
			System.out.println("***********************************************");
			option = sc.next().charAt(0);
			System.out.println("\n");
			
			switch(option)
			{
			case 'a':
			System.out.println("***********************************************");
			System.out.println("balance "+Bal);
			System.out.println("***********************************************");
            System.out.println("\n");
            break;
			
			case 'b':
			System.out.println("***********************************");
			System.out.println("enter the amount to deposit  ");
			System.out.println("***********************************************");
            int amount1 = sc.nextInt();
            Deposit(amount1);
			System.out.println("\n");
			break;
			
			case 'c':
			System.out.println("***********************************************");
            System.out.println("enter amount to withdraw");
			System.out.println("***********************************************");
			int amount2 =sc.nextInt();
			Withdraw(amount2);
			System.out.println("\n");
			break;
			
			case 'd':
			System.out.println("***********************************************");
			getPretransaction();
			System.out.println("***********************************************");
			System.out.println("\n");
			break;
			
			case 'e':
			System.out.println("*******************************");
			break;
			
			}
			
		}
		while(option != 'e');
		System.out.println("thank you for visit");
	}
}
