package MyPackage;

	class Animal {          ///Inheritance Example
	
		void eat()
		{
			System.out.println("im eating");
		}
	}
	

	
