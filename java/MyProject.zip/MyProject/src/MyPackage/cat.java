package MyPackage;

public class cat extends Animal{
	void run()
	{
		System.out.println("im running");
	}

}
