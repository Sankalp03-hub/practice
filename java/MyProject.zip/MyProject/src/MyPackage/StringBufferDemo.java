package MyPackage;

public class StringBufferDemo {

	public static void main(String[] args) {
		{
			StringBuffer sb = new StringBuffer("sankalp java");
			System.out.println(sb.length());
		}
	}

}
