package MyPackage;

import java.util.Scanner;

public class Voting {

	public static void main(String[] args) { //////throw keyword
		Scanner s =new Scanner(System.in);
		System.out.println("Enter your age: ");
		
		int age=s.nextInt();
		try
		{
			if(age<16)
			{
				throw new YoungerAgeException("you are not eligible for voting");
			}
			else
			{
				System.out.println("you can vote successfully");
			}

		}
		catch(Exception e){
			{
				e.printStackTrace();
			}
		}
		
		System.out.println("hello");

	}

}
