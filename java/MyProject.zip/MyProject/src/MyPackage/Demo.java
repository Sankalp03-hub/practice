package MyPackage;

import java.util.Scanner;


public class Demo  {
	
		public static void main(String[] args)
	    {
		 //swapping number by using 3rd number	*****************************************************
	     /* int a=10,b=20;
	      int t;
	      t=a;
	      a=b;
	      b=t;
	      System.out.println("a"+a);
	      System.out.println("b"+b);*/
			
		  //swapping number without using 3rd value	    *********************************************
		  /*int a=10,b=20;
		  a=a+b;
		  b=a-b;
		  a=a-b;
		  System.out.println("a="+a);
	      System.out.println("b="+b);*/
			
		  //fibonakki series          ****************************************************************
		  /*int a=0,b=1;
		  int c;
		  System.out.print(a+" "+b);
		  for(int i=0;i<=10;i++) {
		  c=a+b;
		  System.out.print(" "+c);
		  a=b;
		  b=c;
		  }*/
			
		  //prime number    -->(no which is divided by 1 or itself)***************************
		  /*Scanner s = new Scanner(System.in);
		  System.out.println("Enter the number:");
		  int no = s.nextInt(), b=0;
		  for(int i = 2;i <= no-1;i++) {
			  if(no %i==0)
			  {
				  b=b+1;
			  }	
		  }
		  if(b==0) {
			  System.out.println(a+" is prime no");
		  }
		  else {
			  System.out.println(a+ "is not prime no");

		  }*/
		  
			
		  //even odd    *****************************************************************************
		  /*Scanner s =new Scanner(System.in);
		  System.out.println("enter the number");
		  int a = s.nextInt();
		  int b=a;
		  {
			  if( a % 2==0)
			  {
				  System.out.println("No is even");
			  }
			  else
			  {
				  System.out.println("No is odd");
			  }
		  }*/
			
		  //Armstong number  (like 123 =cube of 1 +cube of 2+cube of 3)******************************
		  //Find length of number
		   	
		 /* Scanner s = new Scanner(System.in);
		  System.out.println("Enter the number:");	
		  int no = s.nextInt();
		  int t1 = no;
		  int length = 0;
		  while(t1 != 0)
		  {
			  t1 = t1/10; 
			  length = length+1;
		  }
		  //At next part find remainder and multiply upto length 
		  int t2 = no;
		  int arm =0;
		  while(t2 != 0)                        //
		  {
			  int mul=1;                        //--->(started loop for evaluate power of number)
			  int rem = t2%10;                            
			  for(int i = 1;i<=length;i++)
			  {
				  mul=mul*rem;
				  
			  }
			  arm=arm+mul;
			  t2=t2/10;
			  
		  }
		  if(arm==no)
		  {
			  System.out.println("number is armstrong number");
			  
		  }
		  else
		  {
			  System.out.println("number is not armstrong number ");
		  }*/
			
		  //Factorial number  *********************************************************************
		  
		  /*Scanner s = new Scanner(System.in);
		  System.out.println("Enter the number:");	
		  int no = s.nextInt();
	      
	      //LOGIC   (example--> factorial of 5 = 5*4*3*3*2*1 =120)
		  int fact=1;
		  
		  for(int i=no;i>=1;i--)
		  {
			  fact=fact*i;
		  }
		  System.out.println("Factorial of "+ no +"is :"+fact);*/
			
			
			
		 //palindrome number   ********************************************************************
		  
		  /*Scanner s = new Scanner(System.in);
		  System.out.println("Enter the number:");	
		  int no = s.nextInt();
		  int temp = no;
		  int rev = 0,rem;
		  while(temp != 0)
		  {
			  rem=temp%10;                 // If no =121 ; 121 % 10 = 1
			  rev=rev*10+rem;
			  temp=temp/10;               //If no = 121 ; 121 / 10 = 10
			  
		  }
		  if(no==rev)
		  {
			  System.out.println(no+" is palindrome number");
		  }
		  else
		  {
			  System.out.println(no+" is not palindrome number");
		  }*/
			
			
          //maximum number in three number   ******************************************************
		/* int a = 12;
		 int b = 67;
		 int c = 34;
		 
		 if(a >=b && a >=c)
		 {
			 System.out.println(a+ "is maximum number" );
		 }
		 else if(b >=a && b >=c)
		 {
			 System.out.println(b+ "is maximum number" );
		 }
		 else
		 {
			 System.out.println(c+ "is maximum number" );
		 }*/
		
			
			
	}
}


	
		
		
	


