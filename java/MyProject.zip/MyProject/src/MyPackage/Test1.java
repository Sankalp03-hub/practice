package MyPackage;

public class Test1 {     ////overriding example(runtime and dynamic polymorphism)
	void show() throws ArithmeticException
	{
		System.out.println("1");
	}

	
}
