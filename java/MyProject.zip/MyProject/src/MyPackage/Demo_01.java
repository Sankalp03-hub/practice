package MyPackage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.sankalp.pojo.Account;

//public class Demo_01 {

//	import java.io.*;
//	import java.util.*;
//	import java.text.*;
//	import java.math.*;
//	import java.util.regex.*;
	public class Demo_01 {
		public static void main(String[] args) {
		String name="sankalp";
		int leng=name.length();
		String rev=" ";
		for(int i=leng-1;i>=0;i--)
		{
			rev=rev+name.charAt(i);
		}
		System.out.println(rev);
		
		
		
		
	}
	
	}
