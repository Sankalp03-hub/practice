package MyPackage;

public class ThreadDemo {

	public static void main(String[] args) {
		
	}

}
