package MyPackage;

public class Test2 extends Test1 {   ////overriding example(runtime and dynamic polymorphism)
		void show() throws ArithmeticException
		{
			System.out.println("2");
			
		}

	public static void main(String[] args) {
			Test1 t1 = new Test1();
			t1.show();
			Test2 t2 = new Test2();
			t2.show();
	}

}
