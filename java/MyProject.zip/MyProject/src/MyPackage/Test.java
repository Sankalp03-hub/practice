package MyPackage;

public class Test {             ///method overloading(compile time (static)polymorphism)
	void show(String a)
	{
		System.out.println("1");
	}
	void show(int a)
	{
		System.out.println("2");
	}

	public static void main(String[] args) {
		Test t = new Test();
		t.show(10);

	}

}
