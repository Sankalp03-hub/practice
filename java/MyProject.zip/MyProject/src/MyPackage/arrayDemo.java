package MyPackage;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class arrayDemo {

	public static void main(String[] args) {
		// FIND DUPICATE NUMBER
		/*int [] a = {3 ,4,3,2,1,2};
		Set<Integer> s =new HashSet<>();
		for (int no:a)
		{
			boolean b = s.add(no);
			if(b==false)
			{
				System.out.print(no+" ");
			}
		} */  // ********************************************************************************
		
		//REMOVE DUPLICATE NUMBER
	/*	int [] a ={3 ,4,3,2,1,2};
		HashSet<Integer> hs = new HashSet<>();
		for (int i =0;i<a.length;i++)
		{
			hs.add(a[i]);
		}
		for(int no : hs)
		{
			System.out.println(no);
		}  */   //********************************************************************************
		
		// FIND DUPLICATE NUMBER FROM TWO ARRAY
	/*	int [] a ={3 ,4,3,2,1,2};
		int [] b = {6,7,9,8,8,2};
		HashSet<Integer> hs = new HashSet<>();
		for(int no:a)
		{
			hs.add(no);
		}
		for(int no: b)
		{
			boolean bl = hs.add(no);
			if(bl==false)
			{
				System.out.println(no+" ");
			}
		} */  //  *******************************************************************************
		
		// FIND MAX AND MIN NUMBER FROM ARRAY
		/*int [] a = {6,7,3,8,9,2};
		int max =a[0];
		for(int i =1;i <a.length;i++)
		{
			if(a[i]>max)  =====================>[for min no we have to change sign to "<".]
			{
			   max=a[i];
			}
		}
		System.out.println(max);
		*/  // ************************************************************************************
		
		//SAPERATE EVEN AND ODD WITH ARRAYLIST
	/*	int []a = {1,7,9,5,4,6};
		ArrayList<Integer> a1 = new ArrayList<>();
		ArrayList<Integer> a2 = new ArrayList<>();

		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				a1.add(a[i]);
			}
			else
			{
				a2.add(a[i]);
			}
		}
		System.out.println("even");
		for(int no:a1)
		{
			System.out.println(no);
		}
		System.out.println("odd");
		for(int no:a2)
		{
			System.out.println(no);
		}*/
		
		
		//PRINT SECOND HIGHEST AND LOWEST VALUE
	/*	int []a = {1,7,9,5,4,6};
		int largest=Integer.MIN_VALUE;           //Put MAX_VALUE when find to 2nd lowest value.
		int second_largest=Integer.MIN_VALUE;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>largest)                     //sign is change ">" to "<" for 2nd lowest value.
			{
				second_largest=largest;
				largest=a[i];
			}
			else if(a[i]>second_largest && a[i]!=largest)    //sign is change ">" to "<" for 2nd lowest value.
			{
				second_largest=a[i];
			}
			
		}
		System.out.println(second_largest); */
		
		//MEARGE TWO ARRAYS
	/*	int []a = {1,2,3};
		int []b = {4,5,6,7,8};
		int a_leng=a.length;
		int b_leng=b.length;
		int c_leng=a_leng+b_leng;
		int []c= new int [c_leng];
		for(int i=0;i<a.length;i++)
		{
			c[i]=a[i];
		}
		for(int i=0;i<b.length;i++)
		{
			c[a.length+i]=b[i];
		}
		for(int i=0;i<c.length;i++)
		{
			System.out.println(c[i]);
		}*/
	}

}
