package MyPackage;



public class rat extends Animal{
	void sleep()
	{
		System.out.println("im sleeping");
	}
	public static void main(String[] args)
	{
		
			Animal a = new Animal();
			a.eat();
			cat c = new cat();
			c.eat();
			c.run();
			rat r = new rat();
			r.eat();
			//r.run();
			r.sleep();
			
			
		}
	
	}



