package MyPackage;

public class YoungerAgeException extends RuntimeException  ////throw keyword 
{
	YoungerAgeException(String msg)
	{
		super(msg);
	}
}

