package com.sankalp.pojo;

public class Saving extends Account {
	private boolean isSalary;
	
	public Saving()
	{
		System.out.println("default constructor of Saving");
	}
	
	public Saving(int accountNumber,String name,double balance,boolean isSalary )
	{
		super(accountNumber,name,balance);
		System.out.println("param. constructor of Saving");
		this.isSalary=isSalary;
	}
	
	
	public boolean withdraw(double amount)
	{
		if(amount>0)
		{
			if(amount > 0)
			{
				if(amount <=getBalance())
				{
					setBalance(getBalance()-amount);
					return true;
				}
				return false;
			}
			else
			{
				if((getBalance()-amount ) >= 1000)
				{
					setBalance(getBalance()-amount);
					return true;
				}
				return false;
			}
		}
		return false;
	}
//	public boolean deposit(double amount)
//	{
//		if(amount > 0)
//		{
//			setBalance(getBalance()+amount);
//			return true;
//		}
//		return false;
//	}
	
	public String toString()
	{
		return "Saving[isSalary ="+isSalary+", toString() ="+super.toString()+"]";
	}

}
