package com.sankalp.pojo;

public class Current extends Account {
	private double overDraftLimit;
	private double initialOverDraftLimit;
	
	public Current()
	{
		
	}
	
	public Current(int accountNumber,String name,double balance,double overDraftLimit)
	{
		super( accountNumber,name,balance);
		this.overDraftLimit = overDraftLimit;
		initialOverDraftLimit =this.overDraftLimit;
	}
	public double getOverDraftLimit()
	{
		return overDraftLimit;
	}
	public void setOverDraftLimit(double overDraftLimit)
	{
		this.overDraftLimit=overDraftLimit;
	}
	
	  public String toString()
	  
	  { return
	  "Current[overDraftLimit="+overDraftLimit+", toString() ="+super.toString()+
	  "]"; }
	 
	
	public boolean withdraw(double amount)
	{
		if(amount>0)
		{
			if(amount<=getBalance())
			{
				setBalance(getBalance()-amount);
				return true;
			}
			else if(amount > getBalance() && amount <= getBalance()+ overDraftLimit)
			{
				amount = amount -getBalance();
				setBalance(0);
				overDraftLimit =overDraftLimit - amount;
				return true;
			}
			else
			{
				return false;
			}
			
		}
		return false;	
	}
	public boolean deposit(double amount)
	{
		if(initialOverDraftLimit == overDraftLimit)
		{
			setBalance(getBalance()+amount);
			return true;
		}
		if(initialOverDraftLimit > overDraftLimit)
		{
			if(amount > initialOverDraftLimit-overDraftLimit)
			{
				amount = amount-(initialOverDraftLimit-overDraftLimit);
				setBalance(getBalance()+amount);
				return true;
			}
			
		}
		if(amount<= initialOverDraftLimit-overDraftLimit)
		{
			overDraftLimit = overDraftLimit + amount;
			return true;

			
		}
		
			return false;
		
	}
}
