package com.sankalp.pojo;

public abstract class Account {

	
		private int accountNumber;
		private String name;
		private double balance;
		
		public Account(){
			System.out.println("default constructor of Account");
			
		}
		public Account(int accountNumber,String name,double balance){
		
			System.out.println("param. constructor of Account");
			this.accountNumber=accountNumber;
			this.name=name;
			this.balance=balance;
			
		}
//		public boolean withdraw(double amount)
//		{
//			if(balance>= amount)
//			{
//				balance = balance-amount;
//				return true;
//			}
//			return false;
//		}
		
		public abstract boolean withdraw(double amount);

		public boolean deposit(double amount)
		{
			if(amount >0)
			{
				balance=balance+amount;
				return true;
			}
			return false;
		}
		
		
		public int getAccountNumber()
		{
			return accountNumber;
		}
		public void setAccountNumber(int accountNumber)
		{
			this.accountNumber=accountNumber;
		}
		public String getName()
		{
			return name;
		}
		public void setName(String name)
		{
			this.name=name;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance)
		{
			this.balance=balance;
		}
		
		
		 public String toString() 
		 { return "Account[accountNumber ="+accountNumber+"name ="+name+"balance ="+balance+ "]"; }
		 
		
	

}
