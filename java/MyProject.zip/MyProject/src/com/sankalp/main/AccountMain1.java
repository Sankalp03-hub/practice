package com.sankalp.main;

import java.util.Scanner;

import com.sankalp.pojo.Account;
import com.sankalp.pojo.Current;
import com.sankalp.pojo.Saving;
public class AccountMain1 {

	public static void main(String[] args) {
		double overDraftLimit;
		int accountChoice;
		int accountNumber = 0;
		double balance;
		String name = null;

		boolean isSaving =false;
		boolean isCurrent =false;
		int amount;
		int transactionChoice;
		String exitorcontinue;
		Account account =null;
		Current current =null;
		
		System.out.println("menu");
		System.out.println("please select type of account");
		System.out.println("1.Current account");
		System.out.println("2.Saving account");
		System.out.println("enter your choice");
		Scanner sc = new Scanner(System.in);
		accountChoice = sc.nextInt();
		
		System.out.println("enter your accountNumber");
		accountNumber =sc.nextInt();
		
		System.out.println("enter your name");
		name = sc.next();
		
		if(accountChoice == 1)
		{
			System.out.println("enter balance");
			balance = sc.nextInt();
			
			isCurrent = true;
			System.out.println("enter overDraftLimit");
			overDraftLimit = sc.nextDouble();
			
			current = new Current(accountNumber,name,balance,overDraftLimit);
			account = current;
			System.out.println("your accout created successfully");
			System.out.println(current);
				
		}
		if (accountChoice ==2)
		{
			System.out.println("enter your accountChoice");
			System.out.println("1.Salary account - 0 Balance");
			System.out.println("2.Saving account - 1000 balance");
			System.out.println("enter your choice");
			accountChoice = sc.nextInt();
			
			if(accountChoice ==1)
			{
				isSaving = true;
				System.out.println("enter the balance");
				balance = sc.nextDouble();
				
				account = new Saving(accountNumber,name,balance,isSaving);
				System.out.println("account created successfully");
				System.out.println(account);
				
			}
			else if(accountChoice ==2)
			{
				System.out.println("enter the balance");
				balance = sc.nextDouble();
				
				while(balance < 1000 )
				{
					System.out.println("please enter the balance greater than 1000");
					balance = sc.nextDouble();
					
				}
				account = new Saving(accountNumber, name,balance,isSaving);
				System.out.println("account created successfully");
				System.out.println(account);
			}
			else
			{
				System.out.println("invalid choice");
			}
			
		}else
		{
			System.out.println("invalid choice");
		}
		do
		{
			System.out.println("transaction menu");
			System.out.println("1.withdraw");
			System.out.println("2.deposit");
			System.out.println("3.check balance");
			if(isCurrent)
			{
				System.out.println("4.display overDraftLimit");
			}
			System.out.println("enter choice");
			transactionChoice = sc.nextInt();
			
			if(transactionChoice ==1)
			{
				System.out.println("enter amount to withdraw");
				amount = sc.nextInt();
				if(account.withdraw(amount))
				{
					System.out.println("transaction successfully");
				}
				else
				{
					System.out.println("transaction failed");
				}
			}
			if(transactionChoice == 2)
			{
				System.out.println("Enter Amount to Deposit");
				amount = sc.nextInt();
				if (account.deposit(amount)) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction Failed");
				}
			}
			if (transactionChoice == 3) {
				System.out.println("Account Balance " + account.getBalance());
			}
			if (transactionChoice == 4 && isCurrent) {
				System.out.println("OverdDraftLimit is " + current.getOverDraftLimit());
			}

			System.out.println("Do you want to continue?");
			System.out.println("yes to Conitnue and no to Exit");
			exitorcontinue = sc.next();
		} while (exitorcontinue.equals("yes"));
		System.out.println("Thank you!!");
	}}

