package com.mindgate.pojo;

import java.util.Scanner;

public class UserDetails {
	private String name;
	private int age;

	public void acceptDetails() {
		Scanner scanner= null;
		try {
			scanner = new Scanner(System.in);
			System.out.println("Enter your Name");
			name = scanner.nextLine();
			System.out.println("Enter your age");
			age = scanner.nextInt();
		} catch (Exception e) {
			System.out.println("Oops... Something went wrong!!!");
		}
		finally {
			scanner.close();
			
		}
		
	}
	public void displayDetails() {

		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
	}

}
