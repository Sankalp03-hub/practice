package com.mindgate.main;

import java.io.IOException;

import com.mindgate.pojo.User;

public class UserMain {

	public static void main(String[] args) {
		User userObj = new User();
		try {
			userObj.print();
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
