package com.mindgate.main;

import com.mindgate.exception.InvalidEmployeeSalaryException;
import com.mindgate.pojo.Employee;

public class EmployeeMainV2 {

	public static void main(String[] args) {
		/*Employee employee = new Employee(101, "Mandar", 0);*/
		Employee employee = new Employee();
		employee.setEmployeeId(101);
		employee.setName("Mandar");
		try {
			employee.setSalary(5000);
		} catch (InvalidEmployeeSalaryException e) {
			
			System.out.println(e.getMessage());;
		}
		System.out.println(employee);

	}

}
