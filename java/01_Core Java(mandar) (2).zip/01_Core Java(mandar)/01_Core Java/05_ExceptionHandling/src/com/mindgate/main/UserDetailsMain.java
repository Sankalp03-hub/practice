package com.mindgate.main;

import com.mindgate.pojo.UserDetails;

public class UserDetailsMain {

	public static void main(String[] args) {
		UserDetails userDetails = new UserDetails();
		
		userDetails.acceptDetails();
		userDetails.displayDetails();

	}

}
