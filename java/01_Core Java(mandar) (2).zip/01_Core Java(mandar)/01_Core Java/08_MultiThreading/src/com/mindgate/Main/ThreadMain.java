package com.mindgate.Main;

import com.mindgate.threads.ThreadOne;

public class ThreadMain {

	public static void main(String[] args) {
		System.out.println("Main Start");
		
		Thread thread =Thread.currentThread();
		System.out.println(thread);
		
		thread.setName("Main Thread");
		thread.setPriority(10);
		
		System.out.println(thread);
		
		
	
		System.out.println("Main is creating child Thread");
		
		ThreadOne one = new ThreadOne();
		one.start();
		
		for (int i = 0; i < 1000; i++) {
			System.out.println("Main "+i+ "...");
			
		}
		System.out.println("Main End");
	}

}
