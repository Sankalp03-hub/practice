package com.mindgate.threads;

import com.mindgate.resource.Call;

public class CallerTwo extends Thread {
	private Call call;
	private String message;
	
	
	 public CallerTwo(com.mindgate.resource.Call call, String message) {
		
		this.call = call;
		this.message = message;
	}

	 @Override
		public void run() {
		 call.callMe(message);
		}
}
