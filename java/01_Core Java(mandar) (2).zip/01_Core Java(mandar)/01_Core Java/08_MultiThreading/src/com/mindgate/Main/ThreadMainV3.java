package com.mindgate.Main;

import com.mindgate.threads.ThreadFour;
import com.mindgate.threads.ThreadOne;
import com.mindgate.threads.ThreadThree;
import com.mindgate.threads.ThreadTwo;

public class ThreadMainV3 {

	public static void main(String[] args) {
		System.out.println("Main is creating child Thread");

		ThreadThree threadThree = new ThreadThree();
		ThreadFour threadFour = new ThreadFour();

		threadThree.start();
		try {
			threadThree.join();
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		threadFour.start();
		try {
			threadFour.join();
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Main Ends");

	}

}
