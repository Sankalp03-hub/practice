package com.mindgate.threads;

public class ThreadFour extends Thread {
	@Override
	public void run() {
		System.out.println("ThreadTwo");

		for (int i = 0; i < 10; i++) {
			System.out.println("T2 "+i+ "...");
			
		}
}
}
