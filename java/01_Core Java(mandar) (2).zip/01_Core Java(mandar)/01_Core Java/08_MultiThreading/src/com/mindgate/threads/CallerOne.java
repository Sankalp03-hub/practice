package com.mindgate.threads;

import com.mindgate.resource.Call;

public class CallerOne extends Thread {
	private Call call;
	private String message;
	
	
	 public CallerOne(Call call, String message) {
		
		this.call = call;
		this.message = message;
	}


	@Override
	public void run() {
		call.callMe(message);
	}
}
