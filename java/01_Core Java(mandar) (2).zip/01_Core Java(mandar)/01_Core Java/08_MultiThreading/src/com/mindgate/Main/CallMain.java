package com.mindgate.Main;

import com.mindgate.resource.Call;
import com.mindgate.threads.CallerOne;
import com.mindgate.threads.CallerTwo;

public class CallMain {

	public static void main(String[] args) {
		Call call = new Call();
		
		CallerOne callerOne = new CallerOne(call, "Hi ...This is caller one");
		CallerTwo callerTwo = new CallerTwo(call, "Hello ...This is caller Two");
		
		callerOne.start();
		callerTwo.start();
		
		

	}

}
