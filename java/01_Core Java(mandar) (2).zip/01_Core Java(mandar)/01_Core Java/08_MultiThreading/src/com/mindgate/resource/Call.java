package com.mindgate.resource;

//Resource
public class Call { 
	public synchronized void callMe(String message)
	{
	
		System.out.print("[");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.print(message);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.print("]");
	}

}
