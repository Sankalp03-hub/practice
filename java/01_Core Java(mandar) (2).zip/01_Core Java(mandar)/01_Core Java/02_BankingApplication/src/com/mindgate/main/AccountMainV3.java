package com.mindgate.main;

import com.mindgate.pojo.Account;

public class AccountMainV3 {

	public static void main(String[] args) {
		Account account = new Account();
		System.out.println(account);
		System.out.println("-----------------------------");
		
		Account account2 = new Account(101,"Nikhil",5000);
		System.out.println(account2);

	}

}
