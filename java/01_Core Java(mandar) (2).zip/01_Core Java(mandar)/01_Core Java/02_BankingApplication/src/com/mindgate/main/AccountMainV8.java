package com.mindgate.main;

import com.mindgate.pojo.Current;

public class AccountMainV8 {

	public static void main(String[] args) {
		
		Current current = new Current(101,"Mandar",50000,100000);
		
		System.out.println(current);
		
		current.withdraw(10000);
		System.out.println("Balance:: "+current.getBalance());//40000
		System.out.println("OverDraftLimit:: "+current.getOverDraftLimit());//100000
		
		System.out.println("------------------------------------");
		
		current.withdraw(50000);
		System.out.println("Balance:: "+current.getBalance());//0
		System.out.println("OverDraftLimit:: "+current.getOverDraftLimit());//90000
		
		System.out.println("------------------------------------");
		
		current.deposit(5000);
		System.out.println("Balance:: "+current.getBalance());//0
		System.out.println("OverDraftLimit:: "+current.getOverDraftLimit());//95000
		
		System.out.println("------------------------------------");
		
		current.deposit(50000);
		System.out.println("Balance:: "+current.getBalance());//45000
		System.out.println("OverDraftLimit:: "+ current.getOverDraftLimit());//100000

		Current current2 = new Current(1012,"Vivek",25000,200000);
		
		System.out.println(current);
		
		current2.withdraw(10000);
		System.out.println("Balance:: "+current2.getBalance());//40000
		System.out.println("OverDraftLimit:: "+current2.getOverDraftLimit());//100000
		
		System.out.println("------------------------------------");
		
		current2.withdraw(50000);
		System.out.println("Balance:: "+current2.getBalance());//0
		System.out.println("OverDraftLimit:: "+current2.getOverDraftLimit());//90000
		
		System.out.println("------------------------------------");
		
		current2.deposit(5000);
		System.out.println("Balance:: "+current2.getBalance());//0
		System.out.println("OverDraftLimit:: "+current2.getOverDraftLimit());//95000
		
		System.out.println("------------------------------------");
		
		current2.deposit(50000);
		System.out.println("Balance:: "+current2.getBalance());//45000
		System.out.println("OverDraftLimit:: "+ current2.getOverDraftLimit());//100000

	}

}
