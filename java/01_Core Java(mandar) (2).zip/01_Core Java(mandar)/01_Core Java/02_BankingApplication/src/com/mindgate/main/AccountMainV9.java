package com.mindgate.main;

import java.util.Scanner;

import com.mindgate.pojo.Account;
import com.mindgate.pojo.Current;
import com.mindgate.pojo.Savings;

public class AccountMainV9 {

	public static void main(String[] args) {
		double overDraftLimit;
		int accountChoice;
		int accountNumber = 0;
		String name = null;
		double balance = 0;
		boolean isSaving = false;
		boolean isCurrent = false;
		int amount;
		int transactionChoice;
		String exitorcontinue;
		Account account = null;
		Current current = null;

		System.out.println("Menu");
		System.out.println("Please select Type of Account");
		System.out.println("1.Current Account");
		System.out.println("2.Savings Account");
		System.out.println("Enter Your Choice");
		Scanner scanner = new Scanner(System.in);
		accountChoice = scanner.nextInt();

		System.out.println("Enter Account number");
		accountNumber = scanner.nextInt();

		System.out.println("Enter your Name");
		name = scanner.next();

		if (accountChoice == 1) {

			System.out.println("Enter Balance");
			balance = scanner.nextDouble();

			isCurrent = true;
			System.out.println("Enter OverDraftLimit");
			overDraftLimit = scanner.nextDouble();

			current = new Current(accountNumber, name, balance, overDraftLimit);
			account = current;
			System.out.println("Your Account created Successfully !");
			System.out.println(current);

		} else if (accountChoice == 2) {

			System.out.println("Please select Type of Saving Account");
			System.out.println("1.Salary Account - 0 Balance");
			System.out.println("2. Savings Account - Main 1000 Balance");
			System.out.println("Enter Your Choice");
			accountChoice = scanner.nextInt();

			if (accountChoice == 1) {
				isSaving = true;

				System.out.println("Enter Balance");
				balance = scanner.nextDouble();

				account = new Savings(accountNumber, name, balance, isSaving);
				System.out.println("Your Account created Successfully !");
				System.out.println(account);

			} else if (accountChoice == 2) {

				System.out.println("Enter Balance");
				balance = scanner.nextDouble();

				while (balance < 1000) {

					System.out.println("Please Enter Amount geater than or equal to 1000");
					balance = scanner.nextDouble();
				}

				account = new Savings(accountNumber, name, balance, isSaving);
				System.out.println("Your Account created Successfully !");
				System.out.println(account);

			} else {
				System.out.println("Invalid Choice");
			}

		} else {
			System.out.println("Invalid Choice");
		}

		do {

			System.out.println("Transaction Menu");
			System.out.println("1.Withdraw");
			System.out.println("2.Deposit");
			System.out.println("3.Display Balance");
			if (isCurrent) {
				System.out.println("4.Display OverDraftLimit");
			}
			System.out.println("Enter your Choice");

			transactionChoice = scanner.nextInt();

			if (transactionChoice == 1) {
				System.out.println("Enter Amount to Withdraw");
				amount = scanner.nextInt();
				if (account.withdraw(amount)) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction Failed");
				}
			}

			if (transactionChoice == 2) {
				System.out.println("Enter Amount to Deposit");
				amount = scanner.nextInt();
				if (account.deposit(amount)) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction Failed");
				}
			}
			if (transactionChoice == 3) {
				System.out.println("Account Balance " + account.getBalance());
			}
			if (transactionChoice == 4 && isCurrent) {
				System.out.println("OverdDraftLimit is " + current.getOverDraftLimit());
			}

			System.out.println("Do you want to continue?");
			System.out.println("yes to Conitnue and no to Exit");
			exitorcontinue = scanner.next();
		} while (exitorcontinue.equals("yes"));
		System.out.println("Thank you!!");
	}
	

}
