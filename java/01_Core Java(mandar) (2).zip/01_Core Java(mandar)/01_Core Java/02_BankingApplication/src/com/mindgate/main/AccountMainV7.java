package com.mindgate.main;

import java.util.Scanner;

import com.mindgate.pojo.Savings;

public class AccountMainV7 {

	public static void main(String[] args) {

		int accountChoice;
		int accountNumber = 0;
		String name = null;
		double balance = 0;
		boolean isSaving = false;
		int amount;
		int transactionChoice;
		String exitorcontinue;
		Savings savings = null;

		System.out.println("Menu");
		System.out.println("Plese select Type of Savings Account");
		System.out.println("1.Salary Account - 0 Balance");
		System.out.println("2. Savings Account - Main 1000 Balance");
		System.out.println("Enter Your Choice");
		Scanner scanner = new Scanner(System.in);
		accountChoice = scanner.nextInt();

		System.out.println("Enter Account number");
		accountNumber = scanner.nextInt();

		System.out.println("Enter your Name");
		name = scanner.next();

		System.out.println("Enter Balance");
		balance = scanner.nextDouble();

		if (accountChoice == 1) {
			isSaving = true;

			savings = new Savings(accountNumber, name, balance, isSaving);
			System.out.println("Your Account created Successfully !");
			System.out.println(savings);

		} else if (accountChoice == 2) {

			savings = new Savings(accountNumber, name, balance, isSaving);
			System.out.println("Your Account created Successfully !");
			System.out.println(savings);

		} else {
			System.out.println("Invalid Choice");
		}
		do {

			System.out.println("Transaction Menu");
			System.out.println("1.Withdraw");
			System.out.println("2.Deposit");
			System.out.println("3.Display Balance");
			System.out.println("Enter your Choice");
			transactionChoice = scanner.nextInt();

			if (transactionChoice == 1) {
				System.out.println("Enter Amount to Withdraw");
				amount = scanner.nextInt();
				if (savings.withdraw(amount)) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction Failed");
				}
			}

			if (transactionChoice == 2) {
				System.out.println("Enter Amount to Deposit");
				amount = scanner.nextInt();
				if (savings.deposit(amount)) {
					System.out.println("Transaction Success");
				} else {
					System.out.println("Transaction Failed");
				}
			}
			if (transactionChoice == 3) {
				System.out.println("Account Balance " + savings.getBalance());
			}

			System.out.println("Do you want to continue?");
			System.out.println("yes to Conitnue and no to Exit");
			exitorcontinue = scanner.next();
		} while (exitorcontinue.equals("yes"));
		System.out.println("Thank you!!");
	}
}
