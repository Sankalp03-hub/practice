package com.mindgate.main;

import com.mindgate.pojo.Account;

public class AccountMainV1 {

	public static void main(String[] args) {
		Account account = new Account();
		
		account.setAccountNumber(101);
		account.setName("Mandar");
		account.setBalance(1000);
		
		System.out.println("-------------------------------");
		
		System.out.println("Account Number "+account.getAccountNumber());
		System.out.println("Naame "+account.getName());
		System.out.println("Balance "+account.getBalance());

	}

}
