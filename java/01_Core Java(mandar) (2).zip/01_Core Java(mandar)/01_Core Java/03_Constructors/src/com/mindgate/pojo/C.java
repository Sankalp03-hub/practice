package com.mindgate.pojo;

class A {
	int x;

	public A() {
		System.out.println("Default Constructor of A");
	}

	public A(int x) {
		this.x = x;
		System.out.println("param Constructor of A");
	}

}

class B extends A {
	int y;

	public B() {
		System.out.println("Default Constructor of B");
	}

	public B(int y) {
		super(y);
		this.y = y;
		System.out.println("param Constructor of B");
	}
}

public class C extends B {
	int z;

	public C() {
		
		System.out.println("Default Constructor of C");
	}

	public C(int z) {
		super(z);
		this.z = z;
		System.out.println("param Constructor of C");
	}
}