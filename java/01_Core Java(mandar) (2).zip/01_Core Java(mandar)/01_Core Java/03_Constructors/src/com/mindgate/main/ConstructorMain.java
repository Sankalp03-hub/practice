package com.mindgate.main;

import com.mindgate.pojo.C;

public class ConstructorMain {

	public static void main(String[] args) {
		
		//C c = new C();
		C c = new C(10);
	}

}
