package com.mindgate.threads;

public class ThreadOne extends Thread {
	@Override
	public void run() {
		System.out.println("ThreadOne");
		

		for (int i = 0; i < 100; i++) {
			System.out.println("T1 "+i+ "...");
			
		}
		System.out.println("ThreadOne Ends");
		
	}

}
