package com.mindgate.threads;

public class ThreadThree extends Thread {
	@Override
	public void run() {
		//System.out.println("ThreadOne");


		for (int i = 0; i < 10; i++) {
			System.out.println("T1 "+i+ "...");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
		
		
	}
}
