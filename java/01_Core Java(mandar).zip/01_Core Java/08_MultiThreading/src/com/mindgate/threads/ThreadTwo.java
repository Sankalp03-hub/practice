package com.mindgate.threads;

public class ThreadTwo implements Runnable{

	@Override
	public void run() {
		System.out.println("ThreadTwo");

		for (int i = 0; i < 100; i++) {
			System.out.println("T2 "+i+ "...");
			
		}
		System.out.println("ThreadTwo Ends");
		
	}
	
}
