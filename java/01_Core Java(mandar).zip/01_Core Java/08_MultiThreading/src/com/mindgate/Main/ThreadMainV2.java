package com.mindgate.Main;

import com.mindgate.threads.ThreadTwo;

public class ThreadMainV2 {

	public static void main(String[] args) {
		System.out.println("Main Start");
		
		System.out.println("Main is creating child Thread");
		ThreadTwo threadTwo = new ThreadTwo();
		Thread thread = new Thread(threadTwo);
		thread.start();
		
		for (int i = 0; i < 1000; i++) {
			System.out.println("Main "+i+ "...");
			
		}

	}

}
