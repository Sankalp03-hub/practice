package com.mindgate.pojo;

public class Employee {

	private int employeId;
	private String name;
	private double salary;

	
	  public Employee() {
	  
	  }
	 

	public Employee(int employeId, String name, double salary) {
		super();
		this.employeId = employeId;
		this.name = name;
		this.salary = salary;
	}

	public int getEmployeeId() {
		return employeId;
	}

	public void setEmployeId(int employeId) {
		this.employeId = employeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [employeId=" + employeId + ", name=" + name + ", salary=" + salary + "]";
	}

}
