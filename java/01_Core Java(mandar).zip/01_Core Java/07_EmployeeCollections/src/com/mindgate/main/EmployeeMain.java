package com.mindgate.main;

import java.util.List;
import java.util.Scanner;

import com.mindgate.dao.EmployeeCollectionDAO;
import com.mindgate.pojo.Employee;

public class EmployeeMain {

	public static void main(String[] args) {

/*		Employee employee = new Employee(101, "Mandar", 10000);
		Employee employee1 = new Employee(102, "Vishal", 10000);
		Employee employee2 = new Employee(103, "Vivek", 10000);
		EmployeeCollectionDAO dao = new EmployeeCollectionDAO();
		dao.addEmployee(employee);
		dao.addEmployee(employee1);
		dao.addEmployee(employee2);
		
		
		
		System.out.println("_-------------------------");
		System.out.println("Calling getAll");
		List<Employee> emps = dao.getAllEmployees();
		for (Employee emp : emps) {
			System.out.println(emp);
		}
		System.out.println("------------------------------------");
		
		//System.out.println(dao.getEmployee(102));
		
		Employee emp = dao.getEmployee(108);
		if(emp != null)
		{
			System.out.println(emp);
		}
		else {
			System.out.println("Employe not found");
		}
		
		System.out.println("---------------------------------");
		if(dao.removeEmployee(101))
		{
			System.out.println("Emplyee sucessfully deleted");
		}
		else {
			System.out.println("Employe not found");
		}
		
		System.out.println("Back to Main");*/
		
		Scanner scanner = new Scanner(System.in);
		Employee employee = null;
		EmployeeCollectionDAO employeeCollectionDAO = new EmployeeCollectionDAO();
		int choice;
		int employeeId;
		String name;
		double salary;
		String continueChoice;
		
	
		do {
			System.out.println("Menu");
			System.out.println("1.Add Employee");
			System.out.println("2.Delete Employee");
			System.out.println("3.Update Employee Name");
			System.out.println("4.Update Employee Salary");
			System.out.println("5.Get Single Employee");
			System.out.println("6. Get All Employees");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			
			case 1:
				System.out.println("Enter EmployeeId :: ");
				employeeId = scanner.nextInt();
				scanner.nextLine();
				
				System.out.println("Enter Name");
				name = scanner.nextLine();
				System.out.println("Enter Salary");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
				salary = scanner.nextDouble();

				employee = new Employee(employeeId, name, salary);
				
				employeeCollectionDAO.addEmployee(employee);
				
				System.out.println("Employee Added !!");
				break;
				
			case 2:
				System.out.println("Enter EmployeeId :: ");
				employeeId = scanner.nextInt();
				
				if (employeeCollectionDAO.removeEmployee(employeeId)) {
					System.out.println("Employee Deleted Successfully");
				}
				else {
					System.out.println("No employee found !!");
				}
				break;
				
			case 3:
				System.out.println("Enter EmployeeId :: ");
				employeeId = scanner.nextInt();
				scanner.nextLine();
				
				System.out.println("Enter New Name");
				name = scanner.nextLine();

				employee = employeeCollectionDAO.getEmployee(employeeId);
				
				if (employee != null) {
					employee.setName(name);
					//employeeCollectionDAO.updateEmployee(employee);
					System.out.println("Employee Name Updated Successfully");
				}
				break;

			case 4:
				System.out.println("Enter EmployeeId :: ");
				employeeId = scanner.nextInt();
				scanner.nextLine();
				
				System.out.println("Enter New Salary");
				salary = scanner.nextDouble();

				employee = employeeCollectionDAO.getEmployee(employeeId);
				
				if (employee != null) {
					employee.setSalary(salary);
					//employeeCollectionDAO.updateEmployee(employee);
					System.out.println("Employee Salary Updated Successfully");
				}
				break;
			case 5:
				System.out.println("Enter EmployeeId :: ");
				employeeId = scanner.nextInt();
				
				employee = employeeCollectionDAO.getEmployee(employeeId);
				
				if (employee != null) {
					System.out.println(employee);
				} else {
					System.out.println("Employee Not Found");
				}
				break;
			case 6:
				List<Employee> employeeList = employeeCollectionDAO.getAllEmployees();
				
				if (employeeList.size() > 0) {
					for (Employee emp : employeeList) {
						System.out.println(emp);
					}
				} else
					System.out.println("No employees !!");
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue ?? yes || no");
			continueChoice = scanner.next();
		} while (continueChoice.equals("yes"));

	}
}