package com.mindgate.dao;

import java.util.ArrayList;
import java.util.List;

import com.mindgate.pojo.Employee;


public class EmployeeCollectionDAO {
	
	private List<Employee> employeeList = new ArrayList<Employee>();
	
	public void addEmployee(Employee employee)
	{
		employeeList.add(employee);
		
	}
	
	public boolean removeEmployee(int employeeId)
	{
		
		for (Employee employee : employeeList) {
			if(employee.getEmployeeId() == employeeId)
			{
				employeeList.remove(employee);
				return true;
			}
			
		}
		return false;
	}
	public boolean updateEmployee(Employee employee)
	{
		for (Employee emp : employeeList) {
			if (emp.getEmployeeId() == employee.getEmployeeId()) {
				
				/*emp.setName(employee.getName());
				emp.setSalary(employee.getSalary());
				*///emp=employee;
				return true;
				
			}
			
		}
		
		return false;
	}
	public List<Employee> getAllEmployees()
	{
		//System.out.println("hi");
		return employeeList;
		
	}
	public Employee getEmployee(int employeeId)
	{
		for (Employee employee : employeeList) {
			if (employee.getEmployeeId() == employeeId) {
				return employee;
				
			}
			
		}
		return null;
		
	}

}
