package com.mindgate.main;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		Set<Integer> numberSet = new TreeSet<Integer>();
		numberSet.add(1);
		numberSet.add(50);
		numberSet.add(170);
		numberSet.add(60);
		numberSet.add(140);
		numberSet.add(5);
		numberSet.add(99);
		numberSet.add(101);
		
		System.out.println(numberSet);

	}

}
