package com.mindgate.main;

import java.util.ArrayList;

public class ArrayListMain {

	public static void main(String[] args) {
		//ArrayList :: Dynamic in size , non unique objects
		
		ArrayList<String> employeeList = new ArrayList<String>();
		employeeList.add("Mandar");
		employeeList.add("Vishal");
		employeeList.add("Vivek");
		employeeList.add("Nitin");
		employeeList.add("Vivek");
		employeeList.add("Vaibhav");
		System.out.println(employeeList);
		employeeList.remove(2);
		
		System.out.println("-------------------------------");
		
		for (String temp : employeeList) {
			System.out.println(temp);
		}
		

	}

}
