package com.mindgate.main;

import java.util.HashSet;
import java.util.Set;

public class HashSetMain {

	public static void main(String[] args) {
		Set<String> employeeSet = new HashSet<String>();
		employeeSet.add("Mandar");
		employeeSet.add("Vishal");
		employeeSet.add("Vivek");
		employeeSet.add("Nitin");
		employeeSet.add("Vivek");
		employeeSet.add("Vaibhav");

		System.out.println(employeeSet);

	}

}
