package com.mindgate.exception;

public class InvalidEmployeeSalaryException extends Exception {
	
	public String getMessage()
	{
		return "InvalidEmployeeSalaryException :: Enter salary > 0";
		
	}
	

}

