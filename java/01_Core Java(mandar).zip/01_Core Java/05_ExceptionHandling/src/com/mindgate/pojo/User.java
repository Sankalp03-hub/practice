package com.mindgate.pojo;

import java.io.IOException;

public class User {

	public void print() throws IOException {

		
		throw new IOException();

	}
}
