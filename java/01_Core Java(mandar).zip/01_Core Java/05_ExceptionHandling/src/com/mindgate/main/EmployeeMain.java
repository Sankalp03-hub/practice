package com.mindgate.main;

import java.util.InputMismatchException;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		int [] numbers = new int[5];
		Scanner scanner = new Scanner(System.in);
		try {
			for (int i = 0; i <= numbers.length; i++) {
				System.out.println("Enter Number index : : " +i);
				numbers[i] = scanner.nextInt();
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArryLength is "+numbers.length);
			System.out.println("Please enter " +numbers.length +" elements only");
		}
		catch (InputMismatchException e) {
			System.out.println("Invalid Input");
			System.out.println();System.out.println("Please Enter Numbers only");
		}
		catch (Exception e) {
			System.out.println("Exception !!");
		}
		
		System.out.println("-------------------");
		
		System.out.println("Numbers Entered By User");
		for (int i : numbers) {
			System.out.println(i);
			
		}
		scanner.close();

	}

}
