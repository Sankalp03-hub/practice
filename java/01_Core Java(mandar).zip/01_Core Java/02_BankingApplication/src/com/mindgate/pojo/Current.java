package com.mindgate.pojo;

public class Current extends Account {

	private double overDraftLimit;
	private double initaloverDraftLimit;
	
	public Current() {
		
	}


	public Current(int accountNumber, String name, double balance, double overDraftLimit) {
		super(accountNumber, name, balance);
		this.overDraftLimit = overDraftLimit;
		initaloverDraftLimit= this.overDraftLimit;
	}


	public double getOverDraftLimit() {
		return overDraftLimit;
	}


	public void setOverDraftLimit(double overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}


	@Override
	public String toString() {
		return "Current [overDraftLimit=" + overDraftLimit + ", toString()=" + super.toString() + "]";
	}
	
	
	@Override
	public boolean withdraw(double amount) {
	
		if(amount > 0)
		{
			if(amount<=getBalance())
			{
				setBalance(getBalance()-amount);
				return true;
			}
			/*if (amount >getBalance()) {
				
				
				setOverDraftLimit(overDraftLimit-(amount-getBalance()));
				setBalance(0);
				return true;
			}*/
			else if(amount > getBalance() && amount <= getBalance() + overDraftLimit)
			{	amount=amount -getBalance();
				setBalance(0);
				overDraftLimit = overDraftLimit - amount;
				return true;
				
			}
			else
			{
				return false;
			}
			//return false;
		}
		return false;
	}
	
	@Override
	public boolean deposit(double amount) {
		/*if(overDraftLimit<initaloverDraftLimit)
		{
			
			setOverDraftLimit(amount+getOverDraftLimit());
			if(overDraftLimit>initaloverDraftLimit) {
			setBalance(getOverDraftLimit()-initaloverDraftLimit);
			setOverDraftLimit(initaloverDraftLimit);
			}
			return true;
		}
		if(overDraftLimit==initaloverDraftLimit)
		{
			
			setBalance(getBalance()+amount);
			return true;
		}
		
		return false;*/
		if (initaloverDraftLimit == overDraftLimit) {
			setBalance(getBalance() + amount);
			return true;
		}
		if (initaloverDraftLimit > overDraftLimit) {
			if (amount > initaloverDraftLimit - overDraftLimit) {
				amount = amount -( initaloverDraftLimit - overDraftLimit);
				setBalance(getBalance() + amount);
				overDraftLimit = initaloverDraftLimit;
				return true;
				
			}
		}
		if (amount <= initaloverDraftLimit - overDraftLimit) {
			overDraftLimit = overDraftLimit + amount;
			return true;
		}
		return false;
	}
	
}
