package com.mindgate.main;

import com.mindgate.pojo.Account;

public class AccountMainV2 {

	public static void main(String[] args) {
		
		Account account1 = new Account();
		account1.setAccountNumber(101);
		account1.setName("Mandar Dhoke");
		account1.setBalance(1001);
		
		Account account2 = new Account();
		account2.setAccountNumber(102);
		account2.setName("Vishal");
		account2.setBalance(2000);
		
		System.out.println("----------------------------------");
		
		System.out.println(account1.getAccountNumber());
		System.out.println(account1.getName());
		System.out.println(account1.getBalance());
		
		System.out.println("-----------------------------------");
		
		System.out.println(account2.getAccountNumber());
		System.out.println(account2.getName());
		System.out.println(account2.getBalance());
		
		Account account3 =account2;
		
System.out.println("-----------------------------------");
		
		System.out.println(account3.getAccountNumber());
		System.out.println(account3.getName());
		System.out.println(account3.getBalance());
		
		System.out.println("-----------------------------");
		
		System.out.println("name changed");
		account3.setName("Virat Kohli");
		
		
		System.out.println("-----------------------------------");
		System.out.println("account2");
		System.out.println("Account number "+account2.getAccountNumber());
		System.out.println("Name "+account2.getName());
		System.out.println("Balance "+account2.getBalance());
		
		
		System.out.println("-----------------------------------");
		System.out.println("account3");
		System.out.println("Account number "+account3.getAccountNumber());
		System.out.println("Name "+account3.getName());
		System.out.println("Balance "+account3.getBalance());
		
		System.out.println();
		
		System.out.println(account1.hashCode());
		System.out.println(account2.hashCode());
		System.out.println(account3.hashCode());
		
		System.out.println();
		
		System.out.println(account1);
		System.out.println(account2);
		System.out.println(account3);
		
		
		
	}

}
