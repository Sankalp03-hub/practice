package com.mindgate.main;

import com.mindgate.pojo.Savings;

public class AccountMainV5 {

	public static void main(String[] args) {
		Savings savings = new Savings();
		
		
	}

}
