package com.mindgate.main;

import java.util.Scanner;

import com.mindgate.pojo.Savings;

public class AccountMainV6 {

	public static void main(String[] args) {
		
	
		Savings savings = new Savings(101, "Mandar Dhoke", 5000, true);

		System.out.println(savings);

		if (savings.withdraw(4100)) {
			
			System.out.println("Transaction sucessfull");

		}
		else {
			System.out.println("Transaction Failed");
		}
		
		System.out.println();

		System.out.println(savings);

	}

}
