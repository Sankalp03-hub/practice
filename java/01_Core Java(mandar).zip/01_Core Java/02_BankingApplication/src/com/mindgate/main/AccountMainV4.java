package com.mindgate.main;

import java.util.Scanner;

import com.mindgate.pojo.Account;

public class AccountMainV4 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int accountNumber;
		String name;
		double balance;
		
		int amount;
		
		System.out.println("Enter AccountNumber");
		accountNumber = scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.println("Enter Name");
		name = scanner.nextLine();
		
		System.out.println("Enter Balance");
		balance =scanner.nextDouble();
		
		Account account = new Account(accountNumber,name,balance);
		System.out.println(account);
		
		
		System.out.println("Enter amount to deposit");
		amount = scanner.nextInt();
		boolean result = account.deposit(amount);
		if (result) {
			System.out.println("Transaction Success");
		} else {
			System.out.println("Transaction Failed");
		}
		System.out.println(account);
		
		System.out.println("Calling Withdraw");
		System.out.println("Enter amount to withdraw");
		amount = scanner.nextInt();
		
		result=account.withdraw(amount);
		if (result) {
			System.out.println("Transaction Success");
		} else {
			System.out.println("Transaction Failed");
		}
		System.out.println(account);
		scanner.close();
		
		
		
		

	}

}
