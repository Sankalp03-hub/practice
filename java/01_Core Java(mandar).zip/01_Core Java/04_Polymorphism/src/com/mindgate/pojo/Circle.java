package com.mindgate.pojo;

public class Circle extends Shapes {
	
	@Override
	public void draw() {
	System.out.println("Drawing Circle");
	}
}
