package com.mindgate.pojo;

public class Triangle extends Shapes {
	@Override
	public void draw() {
	System.out.println("Drawing Traingle");
	}
}
