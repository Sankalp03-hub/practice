package com.mindgate.main;


import java.util.Scanner;

import com.mindgate.pojo.Circle;
import com.mindgate.pojo.Line;
import com.mindgate.pojo.Shapes;
import com.mindgate.pojo.Triangle;

public class ShapesMain {

	public static void main(String[] args) {
		
		int shapeChoice;
		String continueChoice;
		Shapes shapes= null;
		Scanner scanner = new Scanner(System.in);
		do {
		System.out.println("Menu");
		System.out.println("1.Draw Circle");
		System.out.println("2.Draw Triangle");
		System.out.println("3.Draw Line");
		System.out.println("Enter your choice: ");
		
		shapeChoice= scanner.nextInt();
		
		switch(shapeChoice) {
		case 1:
			shapes = new Circle();
			break;
		
		case 2:
			shapes = new Triangle();
			break;
			
		case 3:
			shapes = new Line() ;
			break;
		default:
			shapes = new Shapes();
			break;
			
		}
		shapes.draw();
		System.out.println("Do You What to Continue Drawing?");
		System.out.println("yes to continue And no to Exit");
		continueChoice= scanner.next();
		}while(continueChoice.equals("yes"));
		System.out.println("Thank you!");
			
	}

}
